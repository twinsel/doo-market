import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { ShopData, Product, CartItem, Order, User, Review, Category, Banner, Section, StoreSettings } from '../types';
import { initialShopData } from '../data/initialData';

const STORAGE_SHOP_DATA = 'doo_shop_data_v2';
const STORAGE_CART = 'doo_cart_v2';
const STORAGE_WISHLIST = 'doo_wishlist_v2';
const STORAGE_USER = 'doo_buyer_session_v2';

interface ShopContextType {
  data: ShopData;
  cart: CartItem[];
  wishlist: string[];
  currentUser: User | null;
  isAuthenticated: boolean;
  isLoggingOut: boolean;
  logoutMsg: string;
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  addToCart: (productId: string, quantity?: number, selectedColor?: string, selectedSize?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  getProduct: (id: string) => Product | undefined;
  getProductsByCategory: (categoryId: string) => Product[];
  getFlashProducts: () => Product[];
  getFeaturedProducts: () => Product[];
  getNewProducts: () => Product[];
  getBestsellers: () => Product[];
  searchProducts: (query: string) => Product[];
  checkoutOrder: (customer: { name: string; phone: string; city: string; address: string; paymentMethod: 'cod' | 'card' | 'wallet' }) => { ok: boolean; orderId?: string; error?: string };
  addReview: (productId: string, rating: number, comment: string, userName?: string) => void;
  login: (user: Partial<User>) => void;
  logout: () => void;
  updateSettings: (settings: Partial<StoreSettings>) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, category: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  resetData: () => void;
  syncStatus: 'idle' | 'loading' | 'synced';
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load data from localStorage or fallback to initialShopData
  const [data, setData] = useState<ShopData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SHOP_DATA);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...initialShopData,
          ...parsed,
          settings: { ...initialShopData.settings, ...parsed.settings },
          categories: parsed.categories && parsed.categories.length ? parsed.categories : initialShopData.categories,
          products: parsed.products && parsed.products.length ? parsed.products : initialShopData.products,
          banners: parsed.banners && parsed.banners.length ? parsed.banners : initialShopData.banners,
          sections: parsed.sections && parsed.sections.length ? parsed.sections : initialShopData.sections,
          orders: parsed.orders || initialShopData.orders,
          reviews: parsed.reviews || initialShopData.reviews,
        };
      }
    } catch (e) {
      console.error('Failed to load shop data from storage:', e);
    }
    return initialShopData;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_WISHLIST);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_USER);
      return saved ? JSON.parse(saved) : { id: 'usr-1', name: 'أحمد المنصور', email: 'ahmed@example.com', phone: '0501234567', role: 'admin' };
    } catch {
      return null;
    }
  });

  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [logoutMsg, setLogoutMsg] = useState('');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'loading' | 'synced'>('idle');

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SHOP_DATA, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save shop data:', e);
    }
  }, [data]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CART, JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart:', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_WISHLIST, JSON.stringify(wishlist));
    } catch (e) {
      console.error('Failed to save wishlist:', e);
    }
  }, [wishlist]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_USER, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_USER);
      }
    } catch (e) {
      console.error('Failed to save user:', e);
    }
  }, [currentUser]);

  // Cart calculations
  const cartCount = useMemo(() => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  }, [cart]);

  const cartTotal = useMemo(() => {
    return cart.reduce((total, item) => {
      const prod = data.products.find(p => String(p.id) === String(item.productId));
      return total + (prod ? prod.price * item.quantity : 0);
    }, 0);
  }, [cart, data.products]);

  const wishlistCount = wishlist.length;

  const addToCart = useCallback((productId: string, quantity = 1, selectedColor?: string, selectedSize?: string) => {
    const holdHours = data.settings.cartHoldHours || 1;
    const reservedUntil = new Date(Date.now() + holdHours * 3600 * 1000).toISOString();

    setCart(prev => {
      // البحث عن منتج مطابق تماماً (نفس المعرف واللون والمقاس)
      const existingIndex = prev.findIndex(item =>
        String(item.productId) === String(productId) &&
        item.selectedColor === selectedColor &&
        item.selectedSize === selectedSize
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity,
          reservedUntil
        };
        return updated;
      } else {
        return [...prev, { productId, quantity, selectedColor, selectedSize, reservedUntil }];
      }
    });
  }, [data.settings.cartHoldHours]);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prev => prev.filter(item => String(item.productId) !== String(productId)));
  }, []);

  const updateCartQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => {
      if (String(item.productId) === String(productId)) {
        return { ...item, quantity };
      }
      return item;
    }));
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const toggleWishlist = useCallback((productId: string) => {
    setWishlist(prev => {
      const exists = prev.some(id => String(id) === String(productId));
      if (exists) {
        return prev.filter(id => String(id) !== String(productId));
      } else {
        return [...prev, productId];
      }
    });
  }, []);

  const getProduct = useCallback((id: string) => {
    return data.products.find(p => String(p.id) === String(id));
  }, [data.products]);

  const getProductsByCategory = useCallback((categoryId: string) => {
    return data.products.filter(p => p.active && p.categoryId === categoryId);
  }, [data.products]);

  const getFlashProducts = useCallback(() => {
    return data.products.filter(p => p.active && p.flashDeal);
  }, [data.products]);

  const getFeaturedProducts = useCallback(() => {
    return data.products.filter(p => p.active && p.featured);
  }, [data.products]);

  const getNewProducts = useCallback(() => {
    return data.products.filter(p => p.active && (p.isNew || p.id.includes('p1') || p.id.includes('p2') || p.id.includes('p4') || p.id.includes('p6')));
  }, [data.products]);

  const getBestsellers = useCallback(() => {
    return [...data.products.filter(p => p.active)].sort((a, b) => (b.sold || 0) - (a.sold || 0));
  }, [data.products]);

  const searchProducts = useCallback((query: string) => {
    if (!query || !query.trim()) return [];
    const q = query.trim().toLowerCase();
    return data.products.filter(p => 
      p.active && (
        p.name.toLowerCase().includes(q) ||
        (p.nameEn && p.nameEn.toLowerCase().includes(q)) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
      )
    );
  }, [data.products]);

  const checkoutOrder = useCallback((customer: { name: string; phone: string; city: string; address: string; paymentMethod: 'cod' | 'card' | 'wallet' }) => {
    if (cart.length === 0) {
      return { ok: false, error: 'السلة فارغة' };
    }

    const orderItems = cart.map(item => {
      const prod = data.products.find(p => String(p.id) === String(item.productId));
      return {
        productId: item.productId,
        name: prod?.name || 'منتج',
        price: prod?.price || 0,
        quantity: item.quantity,
        image: prod?.images[0] || '/images/product-1.jpg',
        selectedColor: item.selectedColor,
        selectedSize: item.selectedSize
      };
    });

    const subtotal = cartTotal;
    const shipping = subtotal >= data.settings.freeShippingMin ? 0 : 25;
    const total = subtotal + shipping;
    const orderId = 'DM' + Math.floor(1000 + Math.random() * 9000);

    const newOrder: Order = {
      id: orderId,
      items: orderItems,
      subtotal,
      shipping,
      discount: 0,
      total,
      status: 'pending',
      paymentMethod: customer.paymentMethod,
      customer: {
        name: customer.name,
        phone: customer.phone,
        city: customer.city,
        address: customer.address
      },
      createdAt: new Date().toISOString(),
      trackingSteps: [
        {
          title: 'تم استلام الطلب',
          description: 'تم تأكيد طلبك بنجاح وجارٍ التجهيز في مستودعاتنا',
          timestamp: 'الآن',
          completed: true
        },
        {
          title: 'قيد التجهيز والتغليف',
          description: 'فحص الجودة وتغليف المنتجات بعناية',
          timestamp: 'قريباً',
          completed: false
        },
        {
          title: 'تم الشحن مع مندوب التوصيل',
          description: 'تسليم الشحنة لشركة الشحن المعتمدة',
          timestamp: 'خلال 24 ساعة',
          completed: false
        },
        {
          title: 'في مرحلة التسليم',
          description: 'المندوب في طريقه إلى عنوانك',
          timestamp: 'المتوقع قريباً',
          completed: false
        },
        {
          title: 'تم التوصيل بنجاح',
          description: 'تم تسليم الطلب للعميل',
          timestamp: 'قريباً',
          completed: false
        }
      ]
    };

    setData(prev => ({
      ...prev,
      orders: [newOrder, ...(prev.orders || [])],
      // Decrement stock for purchased items
      products: prev.products.map(p => {
        const cartMatch = cart.find(ci => String(ci.productId) === String(p.id));
        if (cartMatch) {
          return {
            ...p,
            stock: Math.max(0, p.stock - cartMatch.quantity),
            sold: (p.sold || 0) + cartMatch.quantity
          };
        }
        return p;
      })
    }));

    clearCart();
    return { ok: true, orderId };
  }, [cart, cartTotal, data.products, data.settings.freeShippingMin, clearCart]);

  const addReview = useCallback((productId: string, rating: number, comment: string, userName = 'عميل موثق') => {
    const newRev: Review = {
      id: 'rev-' + Date.now(),
      productId,
      userName,
      rating,
      comment,
      createdAt: 'الآن'
    };

    setData(prev => {
      const updatedReviews = [newRev, ...(prev.reviews || [])];
      // update product rating average and count
      const updatedProducts = prev.products.map(p => {
        if (String(p.id) === String(productId)) {
          const count = (p.reviews || 0) + 1;
          const newRating = Number((((p.rating * (p.reviews || 1)) + rating) / count).toFixed(1));
          return { ...p, reviews: count, rating: newRating };
        }
        return p;
      });

      return {
        ...prev,
        reviews: updatedReviews,
        products: updatedProducts
      };
    });
  }, []);

  const login = useCallback((user: Partial<User>) => {
    const newUser: User = {
      id: user.id || 'usr-' + Date.now(),
      name: user.name || 'مستخدم جديد',
      email: user.email || 'user@doomarket.com',
      phone: user.phone || '0500000000',
      role: user.role || 'buyer'
    };
    setCurrentUser(newUser);
  }, []);

  const logout = useCallback(() => {
    setIsLoggingOut(true);
    setLogoutMsg(data.settings.logoutMessage || 'جاري تسجيل الخروج... نتمنى أن تكون قد استمتعت بتجربة شراء فريدة');
    setTimeout(() => {
      setCurrentUser(null);
      setIsLoggingOut(false);
    }, (data.settings.logoutDuration || 3) * 1000);
  }, [data.settings.logoutMessage, data.settings.logoutDuration]);

  const updateSettings = useCallback((newSettings: Partial<StoreSettings>) => {
    setData(prev => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings }
    }));
  }, []);

  const addProduct = useCallback((product: Omit<Product, 'id'>) => {
    const id = 'p' + (data.products.length + 1);
    const newProd: Product = { ...product, id };
    setData(prev => ({
      ...prev,
      products: [newProd, ...prev.products]
    }));
  }, [data.products.length]);

  const updateProduct = useCallback((id: string, productUpdate: Partial<Product>) => {
    setData(prev => ({
      ...prev,
      products: prev.products.map(p => String(p.id) === String(id) ? { ...p, ...productUpdate } : p)
    }));
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      products: prev.products.filter(p => String(p.id) !== String(id))
    }));
  }, []);

  const addCategory = useCallback((category: Omit<Category, 'id'>) => {
    const id = 'cat-' + Date.now();
    const newCat: Category = { ...category, id };
    setData(prev => ({
      ...prev,
      categories: [...prev.categories, newCat]
    }));
  }, []);

  const updateCategory = useCallback((id: string, categoryUpdate: Partial<Category>) => {
    setData(prev => ({
      ...prev,
      categories: prev.categories.map(c => c.id === id ? { ...c, ...categoryUpdate } : c)
    }));
  }, []);

  const deleteCategory = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      categories: prev.categories.filter(c => c.id !== id)
    }));
  }, []);

  const updateOrderStatus = useCallback((orderId: string, status: Order['status']) => {
    setData(prev => ({
      ...prev,
      orders: (prev.orders || []).map(o => o.id === orderId ? { ...o, status, updatedAt: new Date().toISOString() } : o)
    }));
  }, []);

  const resetData = useCallback(() => {
    localStorage.removeItem(STORAGE_SHOP_DATA);
    setData(initialShopData);
  }, []);

  return (
    <ShopContext.Provider
      value={{
        data,
        cart,
        wishlist,
        currentUser,
        isAuthenticated: !!currentUser,
        isLoggingOut,
        logoutMsg,
        cartCount,
        cartTotal,
        wishlistCount,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        toggleWishlist,
        getProduct,
        getProductsByCategory,
        getFlashProducts,
        getFeaturedProducts,
        getNewProducts,
        getBestsellers,
        searchProducts,
        checkoutOrder,
        addReview,
        login,
        logout,
        updateSettings,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        updateCategory,
        deleteCategory,
        updateOrderStatus,
        resetData,
        syncStatus
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
