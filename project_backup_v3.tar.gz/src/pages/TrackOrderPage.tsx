import React, { useState } from 'react';
import { Search, Package, Truck, CheckCircle2, MapPin, Phone, Calendar, Clock, ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { QrCodeCard } from '../components/QrCodeCard';

export const TrackOrderPage: React.FC = () => {
  const { data } = useShop();
  const [searchCode, setSearchCode] = useState('');
  const [searched, setSearched] = useState(false);

  // default sample order if none searched
  const sampleOrder = data.orders?.[0];
  const matchedOrder = data.orders?.find(
    o => o.id.toLowerCase() === searchCode.trim().toLowerCase() || o.customer.phone.includes(searchCode.trim())
  ) || (searched ? null : sampleOrder);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
  };

  const currencySymbol = data.settings.currencySymbol || 'ر.س';

  return (
    <div className="mx-auto max-w-4xl px-3 py-6 sm:px-4 space-y-6">
      <div className="text-center max-w-md mx-auto">
        <h1 className="text-2xl font-black text-gray-900">تتبع حالة شحنتك</h1>
        <p className="mt-1 text-xs text-gray-500 font-bold">
          أدخل رقم الطلب الخاص بك (مثال: DM8421) أو رقم هاتفك لمعرفة موقع الشحنة الحالي
        </p>
      </div>

      {/* Search Input Box */}
      <form onSubmit={handleSearch} className="max-w-md mx-auto">
        <div className="relative flex items-center">
          <input
            value={searchCode}
            onChange={e => setSearchCode(e.target.value)}
            placeholder="رقم الطلب (مثال: DM8421)"
            className="w-full rounded-2xl border border-gray-200 bg-white py-3.5 pe-24 ps-11 text-sm font-bold shadow-sm outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10"
          />
          <Search size={18} className="absolute start-4 text-gray-400" />
          <button
            type="submit"
            className="absolute end-2 rounded-xl bg-orange-500 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-orange-600 active:scale-95 transition-all"
          >
            تتبع
          </button>
        </div>
      </form>

      {/* Matched Order Tracking Info */}
      {matchedOrder ? (
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-black/5 space-y-6">
          {/* Order Header Meta */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 pb-4">
            <div>
              <span className="text-[10px] font-black uppercase text-gray-400">رقم الطلب</span>
              <div className="text-xl font-black text-orange-600">#{matchedOrder.id}</div>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`rounded-full px-3 py-1 text-xs font-black ${
                  matchedOrder.status === 'delivered'
                    ? 'bg-emerald-50 text-emerald-600'
                    : matchedOrder.status === 'shipped'
                    ? 'bg-blue-50 text-blue-600'
                    : 'bg-orange-50 text-orange-600'
                }`}
              >
                {matchedOrder.status === 'delivered'
                  ? 'تم التوصيل'
                  : matchedOrder.status === 'shipped'
                  ? 'في الطريق إليك'
                  : 'قيد التجهيز'}
              </span>
            </div>
          </div>

          {/* Timeline Visual Steps */}
          <div className="space-y-6 py-2">
            {(matchedOrder.trackingSteps || [
              { title: 'تم استلام الطلب', description: 'تم تأكيد طلبك بنجاح', timestamp: 'أمس 10:30 ص', completed: true },
              { title: 'قيد التجهيز والتغليف', description: 'تم التغليف بمستودعاتنا', timestamp: 'أمس 02:15 م', completed: true },
              { title: 'تم الشحن مع مندوب التوصيل', description: 'الشحنة في طريقها إليك', timestamp: 'اليوم 09:00 ص', completed: true },
              { title: 'في مرحلة التسليم', description: 'المندوب يتجه إلى موقعك', timestamp: 'المتوقع قريباً', completed: false },
              { title: 'تم التوصيل بنجاح', description: 'استلام العميل للشحنة', timestamp: 'قريباً', completed: false }
            ]).map((step, idx, arr) => {
              const isLast = idx === arr.length - 1;
              return (
                <div key={idx} className="relative flex items-start gap-4">
                  {/* Step Connector Line */}
                  {!isLast && (
                    <div
                      className={`absolute start-4 top-7 bottom-[-20px] w-0.5 ${
                        step.completed ? 'bg-orange-500' : 'bg-gray-200'
                      }`}
                    />
                  )}

                  {/* Icon Circle */}
                  <div
                    className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                      step.completed
                        ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {step.completed ? <CheckCircle2 size={16} /> : <Clock size={16} />}
                  </div>

                  {/* Step Info */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4
                        className={`text-sm font-black ${
                          step.completed ? 'text-gray-900' : 'text-gray-400'
                        }`}
                      >
                        {step.title}
                      </h4>
                      <span className="text-[10px] font-bold text-gray-400">{step.timestamp}</span>
                    </div>
                    <p className="mt-0.5 text-xs text-gray-500 font-bold">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Delivery & Customer Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-gray-100 pt-5 text-xs">
            <div className="rounded-2xl bg-gray-50 p-4 space-y-2">
              <div className="flex items-center gap-2 font-black text-gray-900">
                <MapPin size={16} className="text-orange-500" />
                <span>عنوان التوصيل</span>
              </div>
              <p className="text-gray-600 font-bold">{matchedOrder.customer.name}</p>
              <p className="text-gray-500">{matchedOrder.customer.city} · {matchedOrder.customer.address}</p>
              <p className="text-gray-500" dir="ltr">{matchedOrder.customer.phone}</p>
            </div>

            <div className="rounded-2xl bg-gray-50 p-4 space-y-2">
              <div className="flex items-center gap-2 font-black text-gray-900">
                <Package size={16} className="text-orange-500" />
                <span>المنتجات في الشحنة</span>
              </div>
              <div className="space-y-1">
                {matchedOrder.items.map((it, i) => (
                  <div key={i} className="flex justify-between text-gray-700 font-bold">
                    <span>{it.quantity}x {it.name}</span>
                    <span>{it.price * it.quantity} {currencySymbol}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between font-black text-gray-900">
                <span>الإجمالي:</span>
                <span className="text-orange-600">{matchedOrder.total} {currencySymbol}</span>
              </div>
            </div>
          </div>
        </div>
      ) : searched ? (
        <div className="rounded-3xl bg-white p-12 text-center shadow-sm">
          <p className="text-sm font-bold text-gray-500">
            لم نتمكن من العثور على أي شحنة برقم «{searchCode}». الرجاء التأكد من صحة الرقم وإعادة المحاولة.
          </p>
        </div>
      ) : null}

      <div className="max-w-md mx-auto">
        <QrCodeCard />
      </div>
    </div>
  );
};
