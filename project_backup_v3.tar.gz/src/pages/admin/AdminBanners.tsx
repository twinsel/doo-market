import React, { useState } from 'react';
import { Plus, Edit, Trash2, X } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Banner } from '../../types';

export const AdminBannersPage: React.FC = () => {
  const { data, updateSettings } = useShop();
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const banners = [...data.banners].sort((a, b) => a.order - b.order);

  const handleOpenAdd = () => {
    setEditingBanner({
      id: 'banner-' + Date.now(),
      title: '',
      subtitle: '',
      image: '/images/hero-1.jpg',
      link: '/deals',
      buttonText: 'تسوق الآن',
      order: banners.length + 1,
      active: true,
      bgColor: '#FF6A00'
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner || !editingBanner.title.trim()) return;

    const exists = banners.some(b => b.id === editingBanner.id);
    const updated = exists
      ? banners.map(b => (b.id === editingBanner.id ? editingBanner : b))
      : [...banners, editingBanner];

    // save back to data.banners
    data.banners = updated;
    updateSettings({});
    setIsModalOpen(false);
    setEditingBanner(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('حذف هذا البانر؟')) {
      data.banners = banners.filter(b => b.id !== id);
      updateSettings({});
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-slate-900">شرائح الصفحة الرئيسية (البانرات)</h1>
          <p className="text-xs text-slate-500 font-bold mt-0.5">إدارة الإعلانات الكبرى أعلى الصفحة الرئيسية</p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-xs font-black text-white shadow hover:bg-orange-600"
        >
          <Plus size={16} />
          <span>بانر جديد</span>
        </button>
      </div>

      <div className="space-y-4">
        {banners.map(banner => (
          <div
            key={banner.id}
            className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-black/5"
          >
            <div className="flex flex-col sm:flex-row gap-4 p-4">
              <img
                src={banner.image}
                alt=""
                className="h-28 w-full sm:w-48 rounded-2xl object-cover bg-slate-100"
              />
              <div className="flex-1 space-y-1">
                <p className="font-black text-base text-slate-900">{banner.title}</p>
                <p className="text-xs text-slate-500 font-bold">{banner.subtitle}</p>
                <p className="text-xs text-orange-600 font-bold">الرابط: {banner.link} · الزر: {banner.buttonText}</p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setEditingBanner(banner);
                    setIsModalOpen(true);
                  }}
                  className="text-xs font-bold text-orange-600 hover:underline"
                >
                  تعديل
                </button>
                <button
                  onClick={() => handleDelete(banner.id)}
                  className="text-xs font-bold text-red-500 hover:underline"
                >
                  حذف
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && editingBanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-black text-slate-900">تعديل البانر</h2>
              <button onClick={() => setIsModalOpen(false)}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">العنوان الرئيسي *</label>
                <input
                  required
                  value={editingBanner.title}
                  onChange={e => setEditingBanner({ ...editingBanner, title: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">العنوان الفرعي</label>
                <input
                  value={editingBanner.subtitle}
                  onChange={e => setEditingBanner({ ...editingBanner, subtitle: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">رابط الصورة</label>
                <input
                  value={editingBanner.image}
                  onChange={e => setEditingBanner({ ...editingBanner, image: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-bold outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">الرابط الموجه</label>
                  <input
                    value={editingBanner.link}
                    onChange={e => setEditingBanner({ ...editingBanner, link: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-bold outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">نص الزر</label>
                  <input
                    value={editingBanner.buttonText}
                    onChange={e => setEditingBanner({ ...editingBanner, buttonText: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-bold outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl bg-slate-100 px-4 py-2 text-xs font-bold text-slate-700"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-orange-500 px-6 py-2 text-xs font-black text-white"
                >
                  حفظ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
