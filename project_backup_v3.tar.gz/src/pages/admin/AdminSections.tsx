import React, { useState } from 'react';
import {
  ChevronUp,
  ChevronDown,
  Layout,
  Eye,
  EyeOff,
  GripVertical,
  Sparkles,
  TrendingUp,
  Clock,
  Star,
  Zap,
  Tag,
  Layers,
  ArrowUpDown,
  CheckCircle2,
  XCircle,
  ExternalLink
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Section } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';

// ============================================================
// 🏷️  تسميات الأنواع مع أيقونات وألوان
// ============================================================
const typeConfig: Record<string, { label: string; icon: React.ReactNode; color: string; bgColor: string }> = {
  flash: {
    label: 'عروض برق',
    icon: <Zap size={14} />,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50 border-orange-200'
  },
  featured: {
    label: 'مميزة',
    icon: <Star size={14} />,
    color: 'text-amber-600',
    bgColor: 'bg-amber-50 border-amber-200'
  },
  category: {
    label: 'أقسام',
    icon: <Layers size={14} />,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50 border-blue-200'
  },
  new: {
    label: 'وصل حديثاً',
    icon: <Sparkles size={14} />,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50 border-emerald-200'
  },
  bestsellers: {
    label: 'الأكثر مبيعاً',
    icon: <TrendingUp size={14} />,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50 border-purple-200'
  },
  promo: {
    label: 'شريط ترويجي',
    icon: <Tag size={14} />,
    color: 'text-pink-600',
    bgColor: 'bg-pink-50 border-pink-200'
  }
};

// ============================================================
// 📦  مكون القسم الواحد
// ============================================================
const SectionItem: React.FC<{
  section: Section;
  index: number;
  total: number;
  onMove: (id: string, direction: number) => void;
  onToggle: (id: string) => void;
}> = ({ section, index, total, onMove, onToggle }) => {
  const config = typeConfig[section.type] || {
    label: section.type,
    icon: <Layout size={14} />,
    color: 'text-slate-600',
    bgColor: 'bg-slate-50 border-slate-200'
  };

  const isActive = section.active !== false;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`group relative rounded-3xl bg-white p-5 shadow-sm ring-1 transition-all duration-300 ${
        isActive
          ? 'ring-black/5 hover:ring-orange-200 hover:shadow-md'
          : 'ring-black/5 bg-slate-50/50 opacity-60 hover:opacity-80'
      }`}
    >
      <div className="flex items-center gap-4">
        {/* Drag Handle */}
        <div className="hidden sm:flex items-center justify-center text-slate-300 group-hover:text-slate-400 transition-colors cursor-grab">
          <GripVertical size={18} />
        </div>

        {/* Type Badge */}
        <div className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl border ${config.bgColor} ${config.color} font-black text-[10px]`}>
          {config.icon}
          <span>{config.label}</span>
        </div>

        {/* Content */}
        <Link
          to={{ pathname: '/', hash: `#${section.id}` }}
          className="flex-1 text-right min-w-0 group/title"
          title="عرض في المتجر"
        >
          <div className="flex items-center justify-end gap-2">
            <ExternalLink size={12} className="text-slate-300 opacity-0 group-hover/title:opacity-100 transition-opacity" />
            <h3 className={`font-black text-base transition-colors ${
              isActive ? 'text-slate-900 group-hover/title:text-orange-600' : 'text-slate-500'
            }`}>
              {section.title}
            </h3>
          </div>
          <p className="text-xs text-slate-400 font-medium truncate">
            {section.subtitle || 'لا يوجد وصف'}
          </p>
        </Link>

        {/* Order Number */}
        <div className="hidden sm:flex items-center justify-center min-w-[28px]">
          <span className="text-[10px] font-black text-slate-300 bg-slate-100 px-2 py-0.5 rounded-lg">
            #{index + 1}
          </span>
        </div>

        {/* Status Toggle */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onToggle(section.id)}
            className={`relative inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-[10px] font-black transition-all duration-300 ${
              isActive
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                : 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200'
            }`}
          >
            {isActive ? (
              <>
                <CheckCircle2 size={14} className="text-emerald-500" />
                <span>ظاهر</span>
              </>
            ) : (
              <>
                <XCircle size={14} className="text-slate-400" />
                <span>مخفي</span>
              </>
            )}
          </button>
        </div>

        {/* Move Controls */}
        <div className="flex items-center gap-0.5">
          <button
            type="button"
            disabled={index === 0}
            onClick={() => onMove(section.id, -1)}
            className={`rounded-xl p-2 transition-all duration-200 ${
              index === 0
                ? 'text-slate-200 cursor-not-allowed'
                : 'text-slate-400 hover:bg-orange-50 hover:text-orange-600 hover:scale-110'
            }`}
            aria-label="نقل للأعلى"
          >
            <ChevronUp size={18} />
          </button>
          <button
            type="button"
            disabled={index === total - 1}
            onClick={() => onMove(section.id, 1)}
            className={`rounded-xl p-2 transition-all duration-200 ${
              index === total - 1
                ? 'text-slate-200 cursor-not-allowed'
                : 'text-slate-400 hover:bg-orange-50 hover:text-orange-600 hover:scale-110'
            }`}
            aria-label="نقل للأسفل"
          >
            <ChevronDown size={18} />
          </button>
        </div>
      </div>

      {/* Active indicator line */}
      <div className={`absolute bottom-0 right-0 h-0.5 transition-all duration-500 ${
        isActive ? 'w-full bg-gradient-to-l from-orange-500 to-orange-300' : 'w-0'
      }`} />
    </motion.div>
  );
};

// ============================================================
// 🏠  الصفحة الرئيسية
// ============================================================
export const AdminSectionsPage: React.FC = () => {
  const { data, updateSettings } = useShop();

  const sections = [...(data.sections || [])].sort((a, b) => (a.order || 0) - (b.order || 0));

  const moveSection = (id: string, direction: number) => {
    const idx = sections.findIndex(s => s.id === id);
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= sections.length) return;

    const list = [...sections];
    const oldOrder = list[idx].order;
    list[idx] = { ...list[idx], order: list[targetIdx].order };
    list[targetIdx] = { ...list[targetIdx], order: oldOrder };

    data.sections = list;
    updateSettings({});
  };

  const toggleSectionActive = (id: string) => {
    data.sections = (data.sections || []).map(s =>
      s.id === id ? { ...s, active: !s.active } : s
    );
    updateSettings({});
  };

  const visibleCount = sections.filter(s => s.active !== false).length;
  const hiddenCount = sections.filter(s => s.active === false).length;

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 p-8 shadow-2xl">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl" />

        <div className="relative flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black text-white flex items-center gap-3">
              <Layout className="text-orange-400" size={28} />
              أقسام الصفحة الرئيسية
            </h1>
            <p className="text-sm text-slate-400 font-medium mt-1">
              فعّل/أخفِ ورتّب الأقسام — التغييرات تظهر فوراً في المتجر
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-emerald-500/10 backdrop-blur-sm rounded-2xl px-4 py-2 border border-emerald-500/20">
              <Eye size={14} className="text-emerald-400" />
              <span className="text-xs font-black text-emerald-400">{visibleCount} ظاهر</span>
            </div>
            {hiddenCount > 0 && (
              <div className="flex items-center gap-2 bg-slate-500/10 backdrop-blur-sm rounded-2xl px-4 py-2 border border-slate-500/20">
                <EyeOff size={14} className="text-slate-400" />
                <span className="text-xs font-black text-slate-400">{hiddenCount} مخفي</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-black/5 flex items-center justify-between">
          <div className="text-right">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">إجمالي الأقسام</p>
            <p className="text-2xl font-black text-slate-900">{sections.length}</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-500">
            <Layout size={22} />
          </div>
        </div>

        <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-black/5 flex items-center justify-between">
          <div className="text-right">
            <p className="text-[10px] font-black text-emerald-500 uppercase tracking-wider">ظاهرة</p>
            <p className="text-2xl font-black text-slate-900">{visibleCount}</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-500">
            <Eye size={22} />
          </div>
        </div>

        <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-black/5 flex items-center justify-between">
          <div className="text-right">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">مخفية</p>
            <p className="text-2xl font-black text-slate-900">{hiddenCount}</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400">
            <EyeOff size={22} />
          </div>
        </div>

        <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-black/5 flex items-center justify-between">
          <div className="text-right">
            <p className="text-[10px] font-black text-orange-500 uppercase tracking-wider">الترتيب الحالي</p>
            <p className="text-2xl font-black text-slate-900">#{sections.length}</p>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-500">
            <ArrowUpDown size={22} />
          </div>
        </div>
      </div>

      {/* Sections List */}
      <div className="space-y-3">
        {sections.length === 0 ? (
          <div className="text-center py-20 border-2 border-dashed border-slate-200 rounded-3xl">
            <Layout size={48} className="mx-auto text-slate-200 mb-4" />
            <p className="text-lg font-black text-slate-400">لا توجد أقسام</p>
            <p className="text-sm text-slate-300 font-medium">أضف أقساماً جديدة من إعدادات المتجر</p>
          </div>
        ) : (
          sections.map((sec, idx) => (
            <SectionItem
              key={sec.id}
              section={sec}
              index={idx}
              total={sections.length}
              onMove={moveSection}
              onToggle={toggleSectionActive}
            />
          ))
        )}
      </div>

      {/* Helpful Tip */}
      <div className="rounded-3xl bg-gradient-to-br from-slate-50 to-slate-100/50 p-6 border border-slate-200/50">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-2xl bg-slate-800 flex items-center justify-center text-white shadow-lg shadow-slate-900/20">
            <Sparkles size={20} />
          </div>
          <div className="text-right">
            <p className="text-sm font-black text-slate-800">💡 نصائح سريعة</p>
            <ul className="text-xs text-slate-500 font-medium space-y-1 mt-1">
              <li>• استخدم أزرار الأسهم <ChevronUp size={12} className="inline" /> و <ChevronDown size={12} className="inline" /> لتغيير ترتيب الأقسام</li>
              <li>• الأقسام المخفية <EyeOff size={12} className="inline text-slate-400" /> لا تظهر للعملاء في الصفحة الرئيسية</li>
              <li>• التغييرات تنعكس فوراً على المتجر دون الحاجة لتحديث الصفحة</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
