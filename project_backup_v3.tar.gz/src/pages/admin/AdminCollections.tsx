import React, { useState } from 'react';
import { Layers, Star, Zap, Sparkles, TrendingUp } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminCollectionsPage: React.FC = () => {
  const { data, updateProduct } = useShop();
  const [collectionType, setCollectionType] = useState<'featured' | 'new' | 'flash'>('featured');

  const products = data.products || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
          <span>إدارة المجموعات والتشكيلات</span>
          <Layers className="text-orange-500" size={24} />
        </h1>
        <p className="text-xs text-slate-500 font-bold mt-0.5">
          تخصيص وتعيين المنتجات في مجموعات الصفحة الرئيسية
        </p>
      </div>

      {/* Collection Switcher */}
      <div className="flex gap-2 rounded-2xl bg-white p-1.5 shadow-sm ring-1 ring-black/5">
        {[
          { id: 'featured', label: 'منتجات مميزة ⭐', icon: Star },
          { id: 'new', label: 'وصل حديثاً ✨', icon: Sparkles },
          { id: 'flash', label: 'عروض البرق ⚡', icon: Zap }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setCollectionType(tab.id as any)}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black transition-all ${
              collectionType === tab.id
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {products.map(prod => {
          const isIncluded =
            collectionType === 'featured'
              ? prod.featured
              : collectionType === 'new'
              ? prod.isNew
              : prod.flashDeal;

          return (
            <div
              key={prod.id}
              className="flex items-center justify-between rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-black/5"
            >
              <div className="flex items-center gap-3">
                <img src={prod.images[0]} className="h-12 w-12 rounded-xl object-cover bg-slate-50" alt="" />
                <div>
                  <div className="font-black text-xs text-slate-900 line-clamp-1">{prod.name}</div>
                  <div className="text-[10px] text-slate-400 font-bold">{prod.price} {data.settings.currencySymbol}</div>
                </div>
              </div>

              <button
                onClick={() => {
                  if (collectionType === 'featured') {
                    updateProduct(prod.id, { featured: !prod.featured });
                  } else if (collectionType === 'new') {
                    updateProduct(prod.id, { isNew: !prod.isNew });
                  } else {
                    updateProduct(prod.id, { flashDeal: !prod.flashDeal });
                  }
                }}
                className={`rounded-full px-3 py-1 text-xs font-black transition-all ${
                  isIncluded
                    ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isIncluded ? 'مدرج بالقسم' : 'غير مدرج'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
