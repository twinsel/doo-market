import React, { useState } from 'react';
import {
  Users,
  Mail,
  Phone,
  Calendar,
  ShoppingCart,
  Heart,
  TrendingUp,
  Shield,
  Crown,
  Zap,
  X,
  Wallet,
  Clock,
  ExternalLink,
  Package,
  History,
  CheckCircle2
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { motion, AnimatePresence } from 'framer-motion';

import { useNavigate } from 'react-router-dom';

// ============================================================
// 👤  نافذة تفاصيل المستخدم الاحترافية
// ============================================================
const UserDetailModal: React.FC<{
  user: any;
  onClose: () => void;
  initialTab: 'cart' | 'wishlist' | 'orders';
}> = ({ user, onClose, initialTab }) => {
  const { getProduct, data } = useShop();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(initialTab);

  const cartTotal = user.cart.reduce((sum: number, item: any) => {
    const prod = getProduct(item.productId);
    return sum + (prod ? prod.price * item.quantity : 0);
  }, 0);

  // جلب طلبات المستخدم الحقيقية من الداتا إذا وجدت، أو استخدام الموك
  const userOrders = (data.orders || []).filter(o => o.customer.name === user.name);

  const tabs = [
    { id: 'cart', label: 'السلة', icon: ShoppingCart, color: 'text-orange-500', bg: 'bg-orange-50' },
    { id: 'wishlist', label: 'المفضلة', icon: Heart, color: 'text-pink-500', bg: 'bg-pink-50' },
    { id: 'orders', label: 'الطلبات', icon: TrendingUp, color: 'text-emerald-500', bg: 'bg-emerald-50' }
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 sm:p-6"
      dir="rtl"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header Section */}
        <div className="relative bg-gradient-to-br from-slate-900 to-slate-800 p-8 shrink-0">
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
          <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />

          <button
            onClick={onClose}
            className="absolute left-6 top-6 h-10 w-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-sm text-white/60 hover:bg-white/20 hover:text-white transition-all duration-200 z-50"
          >
            <X size={20} />
          </button>

          <div className="relative flex items-center gap-6">
            <div className="relative">
              <div className="h-24 w-24 rounded-3xl bg-slate-100 flex items-center justify-center text-4xl overflow-hidden border-4 border-white/20 shadow-2xl">
                {user.avatar ? <img src={user.avatar} className="h-full w-full object-cover" alt="" /> : user.name.charAt(0)}
              </div>
              <div className={`absolute -bottom-1 -left-1 h-6 w-6 rounded-full border-4 border-white shadow-sm ${user.isOnline ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                {user.isOnline && <div className="h-full w-full rounded-full bg-emerald-500 animate-ping opacity-75" />}
              </div>
            </div>

            <div className="space-y-1.5 text-right text-white">
              <h2 className="text-3xl font-black flex items-center gap-3">
                {user.name}
                {user.role === 'admin' && <Crown size={24} className="text-amber-500" />}
              </h2>
              <div className="flex items-center gap-4 text-slate-400 font-bold text-sm">
                <span className="flex items-center gap-1.5"><Phone size={14} /> {user.phone}</span>
                <span className="flex items-center gap-1.5"><Mail size={14} /> {user.email}</span>
                <span className="flex items-center gap-1.5"><Calendar size={14} /> عضو منذ: {user.joinedAt}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-100 px-8 bg-slate-50/50">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`relative flex items-center gap-2 px-6 py-4 text-sm font-black transition-all ${
                  isActive ? tab.color : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Icon size={18} />
                {tab.label}
                {isActive && (
                  <motion.div
                    layoutId="activeTabLine"
                    className={`absolute bottom-0 left-0 right-0 h-1 rounded-t-full ${tab.bg.replace('50', '500')}`}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 bg-white custom-scrollbar">
          <AnimatePresence mode="wait">
            {activeTab === 'cart' && (
              <motion.div
                key="cart-tab"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between bg-orange-50/50 p-6 rounded-3xl border border-orange-100/50">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-orange-500 text-white flex items-center justify-center">
                      <Wallet size={24} />
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-400">إجمالي قيمة السلة</p>
                      <p className="text-2xl font-black text-slate-900">{cartTotal.toLocaleString()} <span className="text-sm text-orange-500">ر.س</span></p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-black text-slate-400">عدد المنتجات</p>
                    <p className="text-xl font-black text-slate-900">{user.cart.length} قطع</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {user.cart.length > 0 ? (
                    user.cart.map((item: any, idx: number) => {
                      const product = getProduct(item.productId);
                      if (!product) return null;
                      return (
                        <div key={idx} className="flex items-center gap-4 p-4 rounded-3xl border border-slate-100 hover:border-orange-200 transition-all bg-white group">
                          <div className="h-16 w-16 rounded-2xl overflow-hidden shadow-inner ring-1 ring-black/5 shrink-0">
                            <img src={product.images[0]} className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                          </div>
                          <div className="flex-1 text-right">
                            <h4 className="font-black text-sm text-slate-900">{product.name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="px-2 py-0.5 rounded-lg bg-orange-50 border border-orange-100 text-[10px] font-bold text-orange-600">الكمية: {item.quantity}</span>
                              {item.selectedColor && (
                                <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-50 border border-slate-100 text-[10px] font-bold text-slate-500">
                                  <span>اللون:</span>
                                  <div className="w-2.5 h-2.5 rounded-full border border-slate-200" style={{ backgroundColor: item.selectedColor }} />
                                </div>
                              )}
                              {item.selectedSize && (
                                <span className="px-2 py-0.5 rounded-lg bg-slate-50 border border-slate-100 text-[10px] font-bold text-slate-500">المقاس: {item.selectedSize}</span>
                              )}
                              <span className="px-2 py-0.5 rounded-lg bg-slate-50 border border-slate-100 text-[10px] font-bold text-slate-400">{product.categoryId}</span>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                             <span className="text-sm font-black text-slate-900">{product.price.toLocaleString()} ر.س</span>
                             <div className="flex items-center gap-1 text-[10px] font-black text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                                <Clock size={10} />
                                محجوز
                             </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-20 text-slate-300 font-black">السلة فارغة حالياً 🛒</div>
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'wishlist' && (
              <motion.div
                key="wishlist-tab"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                {user.wishlist.length > 0 ? (
                  user.wishlist.map((id: string) => {
                    const product = getProduct(id);
                    if (!product) return null;
                    return (
                      <div key={id} className="flex items-center gap-4 p-4 rounded-3xl border border-pink-100 bg-white hover:border-pink-300 transition-all group">
                        <img src={product.images[0]} className="h-16 w-16 rounded-2xl object-cover ring-1 ring-black/5" alt="" />
                        <div className="flex-1 text-right">
                          <h4 className="font-black text-sm text-slate-900 truncate">{product.name}</h4>
                          <p className="text-xs font-black text-pink-600 mt-1">{product.price} ر.س</p>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-pink-50 flex items-center justify-center text-pink-400">
                          <Heart size={16} fill="currentColor" />
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="col-span-full text-center py-20 text-slate-300 font-black">لم يتم إضافة منتجات للمفضلة بعد ❤️</div>
                )}
              </motion.div>
            )}

            {activeTab === 'orders' && (
              <motion.div
                key="orders-tab"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                {userOrders.length > 0 ? (
                  userOrders.map((order: any) => (
                    <div key={order.id} className="bg-slate-50/50 border border-slate-100 rounded-3xl p-5 hover:bg-white hover:shadow-xl transition-all group">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center">
                            <Package size={20} />
                          </div>
                          <div>
                            <p className="text-xs font-black text-slate-400">طلب رقم #{order.id}</p>
                            <p className="text-sm font-black text-slate-900">{new Date(order.createdAt).toLocaleDateString('ar-SA')}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <span className="text-base font-black text-emerald-600">{order.total.toLocaleString()} ر.س</span>
                          <span className="text-[10px] font-black bg-white px-2 py-0.5 rounded-full border border-slate-100 text-slate-500">{order.items.length} منتجات</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between border-t border-slate-100/50 pt-4">
                        <div className="flex items-center gap-2 text-xs font-black text-emerald-500">
                          <CheckCircle2 size={14} />
                          {order.status === 'delivered' ? 'تم التوصيل' : 'قيد المعالجة'}
                        </div>
                        <button
                          onClick={() => {
                            onClose();
                            navigate(`/admin/orders?id=${order.id}`);
                          }}
                          className="flex items-center gap-1.5 text-xs font-black text-orange-600 hover:gap-2 transition-all"
                        >
                          عرض الطلب <ExternalLink size={14} />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-20 bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
                    <History size={48} className="mx-auto text-slate-200 mb-4" />
                    <p className="text-slate-400 font-black">لا يوجد طلبات سابقة لهذا العميل</p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

// ============================================================
// 🏠  الصفحة الرئيسية للمستخدمين
// ============================================================
export const AdminUsersPage: React.FC = () => {
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [initialTab, setInitialTab] = useState<'cart' | 'wishlist' | 'orders'>('cart');

  const mockUsers = [
    {
      id: 'usr-admin',
      name: 'منذر السماعيل',
      email: 'admin@doomarket.com',
      phone: '0937324210',
      role: 'admin',
      joinedAt: '2026/8/8',
      isOnline: true,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
      cart: [{ productId: 'p3', quantity: 1 }],
      wishlist: [],
      ordersCount: 4,
      totalSpent: 1250,
      badges: ['المدير المؤسس', 'أقدم عضو']
    },
    {
      id: 'usr-buyer-1',
      name: 'سارة العتيبي',
      email: 'sara@example.com',
      phone: '+966559876543',
      role: 'buyer',
      joinedAt: '2024-02-10',
      isOnline: false,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200',
      cart: [
        { productId: 'p1', quantity: 1, selectedColor: '#FF6A00', selectedSize: 'M' },
        { productId: 'p1', quantity: 1, selectedColor: '#000000', selectedSize: 'L' },
        { productId: 'p2', quantity: 1, selectedColor: '#FFFFFF' }
      ],
      wishlist: ['p4', 'p6'],
      ordersCount: 2,
      totalSpent: 450,
      badges: ['عميل مخلص']
    },
    {
      id: 'usr-buyer-2',
      name: 'خالد السبيعي',
      email: 'khaled@example.com',
      phone: '+966541122334',
      role: 'buyer',
      joinedAt: '2024-03-01',
      isOnline: true,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      cart: [],
      wishlist: ['p1'],
      ordersCount: 1,
      totalSpent: 120,
      badges: ['عميل جديد']
    }
  ];

  const handleOpenDetail = (user: any, tab: 'cart' | 'wishlist' | 'orders') => {
    setSelectedUser(user);
    setInitialTab(tab);
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 p-8 shadow-2xl">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl" />

        <div className="relative flex items-center justify-between text-right">
          <div>
            <h1 className="text-3xl font-black text-white flex items-center gap-3">
              <Users className="text-orange-400" size={28} />
              إدارة المستخدمين
            </h1>
            <p className="text-sm text-slate-400 font-medium mt-1">
              قائمة المستخدمين المسجلين وحسابات الإدارة
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-2xl px-4 py-2 border border-white/10">
              <span className="text-xs font-black text-slate-300">إجمالي المستخدمين</span>
              <span className="text-sm font-black text-orange-400">{mockUsers.length}</span>
            </div>
            <div className="flex items-center gap-2 bg-emerald-500/10 backdrop-blur-sm rounded-2xl px-4 py-2 border border-emerald-500/20">
              <Zap size={16} className="text-emerald-400" />
              <span className="text-xs font-black text-emerald-400">{mockUsers.filter(u => u.isOnline).length} متصلون</span>
            </div>
          </div>
        </div>
      </div>

      {/* User Cards - Modern Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockUsers.map((u, index) => (
          <motion.div
            key={u.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ y: -6 }}
            className="relative rounded-3xl bg-white p-6 shadow-sm ring-1 ring-black/5 space-y-4 hover:shadow-xl hover:ring-orange-200 transition-all duration-300 group"
          >
            {/* Status Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-1.5">
              <div className={`h-2.5 w-2.5 rounded-full ${u.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
              <span className="text-[10px] font-black text-slate-400">{u.isOnline ? 'متصل' : 'غير متصل'}</span>
            </div>

            {/* User Info */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="h-16 w-16 rounded-2xl bg-slate-100 overflow-hidden shadow-inner ring-1 ring-black/5">
                  {u.avatar ? (
                    <img src={u.avatar} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" alt="" />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center bg-gradient-to-br from-orange-400 to-orange-500 text-white font-black text-xl">
                       {u.name.charAt(0)}
                    </div>
                  )}
                </div>
                {u.role === 'admin' && (
                  <div className="absolute -top-1.5 -right-1.5 h-6 w-6 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-lg border-2 border-white z-10">
                    <Shield size={10} className="text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1 text-right">
                <h3 className="font-black text-base text-slate-900 group-hover:text-orange-600 transition-colors flex items-center gap-2">
                  {u.name}
                  {u.badges?.includes('المدير المؤسس') && (
                    <Crown size={14} className="text-amber-500" />
                  )}
                </h3>
                <span className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-black mt-1 ${
                  u.role === 'admin'
                    ? 'bg-purple-50 text-purple-700 border border-purple-100'
                    : 'bg-blue-50 text-blue-700 border border-blue-100'
                }`}>
                  {u.role === 'admin' ? 'مدير نظام' : 'مشتري موثق'}
                </span>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-2 text-xs text-slate-600 font-bold border-t border-slate-100 pt-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-normal">{u.phone}</span>
                <span className="flex items-center gap-1.5 text-slate-400 font-normal">
                  <Phone size={12} />
                  الهاتف
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-normal truncate max-w-[150px]">{u.email}</span>
                <span className="flex items-center gap-1.5 text-slate-400 font-normal">
                  <Mail size={12} />
                  البريد
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-normal">{u.joinedAt}</span>
                <span className="flex items-center gap-1.5 text-slate-400 font-normal">
                  <Calendar size={12} />
                  التسجيل
                </span>
              </div>
            </div>

            {/* Stats - Clickable Boxes */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => handleOpenDetail(u, 'cart')}
                className="flex-1 rounded-xl bg-orange-50 p-2.5 text-center border border-orange-100/50 hover:bg-orange-100 transition-colors"
              >
                <ShoppingCart size={14} className="mx-auto text-orange-400 mb-0.5" />
                <p className="text-[10px] text-slate-400 font-medium">السلة</p>
                <p className="font-black text-slate-900 text-sm">{u.cart.length}</p>
              </button>
              <button
                onClick={() => handleOpenDetail(u, 'wishlist')}
                className="flex-1 rounded-xl bg-pink-50 p-2.5 text-center border border-pink-100/50 hover:bg-pink-100 transition-colors"
              >
                <Heart size={14} className="mx-auto text-pink-400 mb-0.5" />
                <p className="text-[10px] text-slate-400 font-medium">المفضلة</p>
                <p className="font-black text-slate-900 text-sm">{u.wishlist.length}</p>
              </button>
              <button
                onClick={() => handleOpenDetail(u, 'orders')}
                className="flex-1 rounded-xl bg-emerald-50 p-2.5 text-center border border-emerald-100/50 hover:bg-emerald-100 transition-colors"
              >
                <TrendingUp size={14} className="mx-auto text-emerald-400 mb-0.5" />
                <p className="text-[10px] text-slate-400 font-medium">الطلبات</p>
                <p className="font-black text-slate-900 text-sm">{u.ordersCount}</p>
              </button>
            </div>

            {/* Footer spent */}
            <div className="flex items-center justify-center pt-2 border-t border-slate-100">
              {u.totalSpent > 0 && (
                <span className="text-[10px] font-black text-slate-500 bg-slate-50 px-3 py-1 rounded-full">
                  إجمالي المشتريات: <span className="text-orange-600">{u.totalSpent.toLocaleString()} ر.س</span>
                </span>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedUser && (
          <UserDetailModal
            user={selectedUser}
            initialTab={initialTab}
            onClose={() => setSelectedUser(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
