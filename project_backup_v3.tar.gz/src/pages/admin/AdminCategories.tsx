// ============================================================
// 🏠  صفحة إدارة تصنيفات المتجر (نسخة محسّنة)
// ============================================================

import React, { useState, useMemo, useCallback } from 'react';
import { Plus, Edit, Trash2, X, ExternalLink, Upload } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Category } from '../../types';
import { useNavigate } from 'react-router-dom';

// ============================================================
// 🔧  مكون التأكيد المدمج (بدلاً من confirm())
// ============================================================
const ConfirmDialog: React.FC<{
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}> = ({ isOpen, title, message, onConfirm, onCancel }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl text-center" dir="rtl">
        <div className="text-4xl mb-3">⚠️</div>
        <h3 className="text-lg font-black text-slate-900 mb-2">{title}</h3>
        <p className="text-sm text-slate-600 mb-6">{message}</p>
        <div className="flex gap-3">
          <button
            onClick={onConfirm}
            className="flex-1 rounded-2xl bg-red-500 py-2.5 text-sm font-black text-white hover:bg-red-600 transition-colors"
          >
            تأكيد
          </button>
          <button
            onClick={onCancel}
            className="flex-1 rounded-2xl bg-slate-100 py-2.5 text-sm font-black text-slate-600 hover:bg-slate-200 transition-colors"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// 🍞  مكون الإشعارات المدمج
// ============================================================
const Toast: React.FC<{
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}> = ({ message, type, onClose }) => {
  React.useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const colors = {
    success: 'bg-emerald-500',
    error: 'bg-red-500',
  };

  return (
    <div className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-2xl text-white font-black text-sm shadow-xl ${colors[type]} animate-in slide-in-from-top-4 duration-300`}>
      {message}
    </div>
  );
};

// ============================================================
// 📝  نافذة الإضافة/التعديل - تصميم مودرن وأنيق
// ============================================================
const CategoryModal: React.FC<{
  category: Category;
  isOpen: boolean;
  isLoading: boolean;
  onClose: () => void;
  onSave: (category: Category) => void;
}> = ({ category, isOpen, isLoading, onClose, onSave }) => {
  const [localCategory, setLocalCategory] = useState<Category>(category);
  const [previewUrl, setPreviewUrl] = useState<string | null>(category.image || null);

  // مزامنة البيانات عند فتح المودال لمنتج مختلف
  React.useEffect(() => {
    setLocalCategory(category);
    setPreviewUrl(category.image || null);
  }, [category]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!localCategory.name.trim()) return;
    onSave(localCategory);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setLocalCategory({ ...localCategory, image: result });
        setPreviewUrl(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setLocalCategory({ ...localCategory, image: '' });
    setPreviewUrl(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div
        className="w-full max-w-lg rounded-3xl bg-white shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300"
        dir="rtl"
      >
        {/* Header */}
        <div className="relative px-8 pt-6 pb-4 border-b border-slate-100 shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onClose();
            }}
            className="absolute left-6 top-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all duration-200 z-50 cursor-pointer pointer-events-auto border border-slate-100 shadow-sm bg-white"
            aria-label="إغلاق النافذة"
          >
            <X size={20} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <span className="text-2xl">📂</span>
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                {localCategory.id ? 'تعديل القسم' : 'قسم جديد'}
              </h2>
              <p className="text-sm text-slate-500 font-medium">
                {localCategory.id ? 'تحديث بيانات القسم' : 'أضف قسمًا جديدًا للمتجر'}
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Name Fields - Side by Side */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700 mr-1">
                الاسم عربي <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 text-sm">🇸🇦</span>
                <input
                  type="text"
                  required
                  value={localCategory.name}
                  onChange={e => setLocalCategory({ ...localCategory, name: e.target.value })}
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/50 pr-10 pl-4 py-2.5 text-sm font-bold outline-none focus:bg-white focus:border-orange-400 focus:ring-4 focus:ring-orange-400/10 transition-all duration-200"
                  placeholder="جمال وعناية"
                  disabled={isLoading}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700 mr-1">
                الاسم إنجليزي
              </label>
              <div className="relative">
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 text-sm">🇬🇧</span>
                <input
                  type="text"
                  value={localCategory.nameEn || ''}
                  onChange={e => setLocalCategory({ ...localCategory, nameEn: e.target.value })}
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/50 pr-10 pl-4 py-2.5 text-sm font-bold outline-none focus:bg-white focus:border-orange-400 focus:ring-4 focus:ring-orange-400/10 transition-all duration-200"
                  placeholder="Beauty"
                  disabled={isLoading}
                />
              </div>
            </div>
          </div>

          {/* Image Upload */}
          <div className="space-y-1.5">
            <label className="block text-xs font-black text-slate-700 mr-1">
              صورة القسم
            </label>
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={localCategory.image || ''}
                  onChange={e => setLocalCategory({ ...localCategory, image: e.target.value })}
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/50 px-4 py-2.5 text-sm font-bold outline-none focus:bg-white focus:border-orange-400 focus:ring-4 focus:ring-orange-400/10 transition-all duration-200"
                  placeholder="رابط الصورة أو اختر من الجهاز"
                  disabled={isLoading}
                />
              </div>
              <div className="relative shrink-0">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  className="h-10 px-5 rounded-2xl bg-orange-50 text-orange-600 font-black text-xs hover:bg-orange-100 transition-all duration-200 flex items-center gap-2 border-2 border-orange-200"
                >
                  <Upload size={16} />
                  <span>رفع</span>
                </button>
              </div>
            </div>
          </div>

          {/* Image Preview */}
          {previewUrl && (
            <div className="relative w-full h-24 rounded-2xl overflow-hidden border-2 border-slate-200 bg-slate-50">
              <img
                src={previewUrl}
                alt="معاينة الصورة"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={handleRemoveImage}
                className="absolute top-2 right-2 p-1 rounded-xl bg-red-500/90 text-white hover:bg-red-600 transition-all duration-200 backdrop-blur-sm"
                aria-label="إزالة الصورة"
              >
                <X size={14} />
              </button>
            </div>
          )}

          {/* Color & Order - Side by Side */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700 text-center">
                لون القسم
              </label>
              <div className="relative h-10 rounded-2xl overflow-hidden border-2 border-slate-200 shadow-sm">
                <input
                  type="color"
                  value={localCategory.color || '#FF6A00'}
                  onChange={e => setLocalCategory({ ...localCategory, color: e.target.value })}
                  className="absolute inset-0 w-full h-full cursor-pointer p-0 border-none scale-150"
                  disabled={isLoading}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700 text-center">
                ترتيب الظهور
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 text-sm">#</span>
                <input
                  type="number"
                  min="1"
                  value={localCategory.order || 1}
                  onChange={e => setLocalCategory({ ...localCategory, order: Number(e.target.value) })}
                  className="w-full rounded-2xl border-2 border-slate-200 bg-slate-50/50 px-4 py-2.5 text-center text-sm font-black outline-none focus:bg-white focus:border-orange-400 focus:ring-4 focus:ring-orange-400/10 transition-all duration-200"
                  disabled={isLoading}
                />
              </div>
            </div>
          </div>

          {/* Active Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50/80 border-2 border-slate-200">
            <div>
              <p className="text-sm font-black text-slate-700">حالة القسم</p>
              <p className="text-[10px] text-slate-400 font-medium">
                {localCategory.active !== false ? 'القسم نشط ومرئي للعملاء' : 'القسم مخفي حالياً'}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={localCategory.active !== false}
                onChange={e => setLocalCategory({ ...localCategory, active: e.target.checked })}
                className="sr-only peer"
                disabled={isLoading}
              />
              <div className="w-10 h-6 bg-slate-200 rounded-full peer peer-checked:bg-orange-500 transition-all duration-300 after:content-[''] after:absolute after:top-1 after:right-1 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all after:duration-300 peer-checked:after:translate-x-[-16px] shadow-inner"></div>
            </label>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-1">
            <button
              type="submit"
              className="flex-[2] rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 py-3 text-sm font-black text-white shadow-lg shadow-orange-500/20 hover:shadow-xl hover:shadow-orange-500/40 hover:scale-[1.02] active:scale-95 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="animate-spin h-4 w-4 border-2 border-white/30 border-t-white rounded-full" />
                  جاري الحفظ...
                </span>
              ) : (
                'حفظ القسم'
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-2xl bg-slate-100 py-3 text-sm font-black text-slate-600 hover:bg-slate-200 hover:text-slate-800 transition-all duration-200 disabled:opacity-50"
              disabled={isLoading}
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ============================================================
// 📂  بطاقة التصنيف الأنيقة
// ============================================================

const formatProductsCount = (count: number): string => {
  if (count === 0) return 'لا توجد أصناف';
  if (count === 1) return 'صنف واحد';
  if (count === 2) return 'صنفان';
  if (count >= 3 && count <= 10) return `${count} أصناف`;
  return `${count} صنفًا`;
};

const CategoryCard: React.FC<{
  category: Category;
  productsCount: number;
  onEdit: (category: Category) => void;
  onDelete: (id: string, name: string) => void;
}> = ({ category, productsCount, onEdit, onDelete }) => {
  const navigate = useNavigate();

  const accentColor = category.color || '#FF6A00';
  const isActive = category.active !== false;
  const categoryImage =
    category.image && category.image.trim()
      ? category.image
      : '/images/product-1.jpg';

  const openCategoryProducts = () => {
    navigate(`/admin/products?category=${category.id}`);
  };

  return (
    <article
      dir="rtl"
      className={`
        group relative overflow-hidden rounded-[1.75rem]
        border border-slate-200/70 bg-white
        shadow-[0_10px_30px_rgba(15,23,42,0.04)]
        transition-all duration-300
        hover:-translate-y-0.5
        hover:border-orange-200
        hover:shadow-[0_18px_45px_rgba(255,106,0,0.10)]
        ${!isActive ? 'bg-slate-50/80' : ''}
      `}
    >
      {/* شريط لون القسم */}
      <div
        aria-hidden="true"
        className="absolute inset-y-0 right-0 w-1.5"
        style={{ backgroundColor: accentColor }}
      />

      {/* توهج خفيف */}
      <div
        aria-hidden="true"
        className="absolute -left-12 -top-12 h-32 w-32 rounded-full opacity-10 blur-3xl transition-opacity duration-300 group-hover:opacity-20"
        style={{ backgroundColor: accentColor }}
      />

      {/* خط علوي لامع */}
      <div
        aria-hidden="true"
        className="absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-orange-200 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      />

      <div className="relative flex items-center gap-4 p-4 sm:p-5">
        {/* منطقة فتح منتجات القسم */}
        <button
          type="button"
          onClick={openCategoryProducts}
          aria-label={`عرض منتجات قسم ${category.name}`}
          title={`عرض منتجات ${category.name}`}
          className="
            flex min-w-0 flex-1 items-center gap-4 rounded-[1.25rem] p-1
            text-right transition-colors
            focus:outline-none focus-visible:ring-2
            focus-visible:ring-orange-500 focus-visible:ring-offset-2
          "
        >
          {/* صورة القسم */}
          <div className="relative h-16 w-16 shrink-0">
            <div
              aria-hidden="true"
              className="absolute inset-0 rounded-[1.4rem] opacity-20 blur-md transition-opacity duration-300 group-hover:opacity-35"
              style={{ backgroundColor: accentColor }}
            />

            <img
              src={categoryImage}
              alt={`صورة قسم ${category.name}`}
              loading="lazy"
              className={`
                relative h-16 w-16 rounded-[1.4rem] object-cover
                ring-1 ring-slate-200 shadow-sm
                transition-transform duration-300
                group-hover:scale-[1.04]
                ${!isActive ? 'grayscale' : ''}
              `}
              onError={(event) => {
                const image = event.currentTarget;
                if (!image.src.includes('/images/product-1.jpg')) {
                  image.src = '/images/product-1.jpg';
                }
              }}
            />

            {/* مؤشر الحالة */}
            <span
              aria-hidden="true"
              className={`
                absolute -bottom-1 -left-1 h-4 w-4 rounded-full
                border-2 border-white shadow-sm
                ${isActive ? 'bg-emerald-500' : 'bg-slate-400'}
              `}
            />
          </div>

          {/* بيانات القسم */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3
                className="
                  truncate text-sm font-black text-slate-900
                  transition-colors group-hover:text-orange-600
                  sm:text-base
                "
              >
                {category.name}
              </h3>

              <span
                className={`
                  inline-flex shrink-0 items-center rounded-full px-2 py-0.5
                  text-[10px] font-black ring-1
                  ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-600 ring-emerald-100'
                      : 'bg-slate-100 text-slate-500 ring-slate-200'
                  }
                `}
              >
                {isActive ? 'نشط' : 'موقوف'}
              </span>
            </div>

            {category.nameEn ? (
              <p
                dir="ltr"
                className="mt-0.5 truncate text-right text-[11px] font-bold text-slate-400"
              >
                {category.nameEn}
              </p>
            ) : (
              <p className="mt-0.5 text-[11px] font-bold text-slate-300">
                بدون اسم إنجليزي
              </p>
            )}

            {/* معلومات إضافية */}
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-1 text-[10px] font-black text-slate-600 ring-1 ring-slate-100">
                <span
                  aria-hidden="true"
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: accentColor }}
                />
                {formatProductsCount(productsCount)}
              </span>

              <span className="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-1 text-[10px] font-black text-slate-500 ring-1 ring-slate-100">
                الترتيب: {category.order || '—'}
              </span>
            </div>
          </div>
        </button>

        {/* أزرار التحكم */}
        <div className="flex shrink-0 items-center gap-1.5 border-r border-slate-100 pr-3">
          <button
            type="button"
            onClick={openCategoryProducts}
            aria-label={`عرض منتجات ${category.name}`}
            title="عرض المنتجات"
            className="
              flex h-9 w-9 items-center justify-center rounded-xl
              bg-blue-50 text-blue-600
              transition-all hover:scale-105 hover:bg-blue-100
              focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500
            "
          >
            <ExternalLink size={16} aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={() => onEdit(category)}
            aria-label={`تعديل قسم ${category.name}`}
            title={`تعديل ${category.name}`}
            className="
              flex h-9 w-9 items-center justify-center rounded-xl
              bg-blue-50 text-blue-600
              transition-all hover:scale-105 hover:bg-blue-100
              focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500
            "
          >
            <Edit size={16} aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={() => onDelete(category.id, category.name)}
            aria-label={`حذف قسم ${category.name}`}
            title={`حذف ${category.name}`}
            className="
              flex h-9 w-9 items-center justify-center rounded-xl
              bg-red-50 text-red-500
              transition-all hover:scale-105 hover:bg-red-100
              focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500
            "
          >
            <Trash2 size={16} aria-hidden="true" />
          </button>
        </div>
      </div>
    </article>
  );
};

// ============================================================
// 🏠  الصفحة الرئيسية
// ============================================================
export const AdminCategoriesPage: React.FC = () => {
  const { data, addCategory, updateCategory, deleteCategory } = useShop();
  const navigate = useNavigate();

  // ====== الحالات ======
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // ====== دوال مساعدة ======
  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
  }, []);

  const showConfirm = useCallback((title: string, message: string, onConfirm: () => void) => {
    setConfirmDialog({ isOpen: true, title, message, onConfirm });
  }, []);

  // ====== معالجة البيانات ======
  const categories = useMemo(() =>
    [...data.categories].sort((a, b) => a.order - b.order),
    [data.categories]
  );

  const getProductsCount = useCallback((categoryId: string) => {
    return (data.products || []).filter(p => p.categoryId === categoryId).length;
  }, [data.products]);

  // ====== فتح نافذة الإضافة ======
  const handleOpenAdd = useCallback(() => {
    const maxOrder = Math.max(...categories.map(c => c.order || 0), 0);
    setEditingCategory({
      id: '',
      name: '',
      nameEn: '',
      icon: 'Package',
      image: '/images/product-1.jpg',
      color: '#FF6A00',
      order: maxOrder + 1,
      active: true
    });
    setIsModalOpen(true);
  }, [categories]);

  // ====== فتح نافذة التعديل ======
  const handleOpenEdit = useCallback((category: Category) => {
    setEditingCategory(category);
    setIsModalOpen(true);
  }, []);

  // ====== معالجة الحفظ ======
  const handleSave = useCallback(async (category: Category) => {
    setIsLoading(true);
    try {
      if (category.id) {
        await updateCategory(category.id, category);
        showToast('تم تحديث التصنيف بنجاح');
      } else {
        const newCategory = {
          ...category,
          id: crypto.randomUUID ? crypto.randomUUID() : `cat-${Date.now()}`,
        };
        await addCategory(newCategory);
        showToast('تم إضافة التصنيف بنجاح');
      }
      setIsModalOpen(false);
      setEditingCategory(null);
    } catch (error) {
      showToast('حدث خطأ أثناء الحفظ', 'error');
      console.error('Error saving category:', error);
    } finally {
      setIsLoading(false);
    }
  }, [addCategory, updateCategory, showToast]);

  // ====== معالجة الحذف ======
  const handleDelete = useCallback((id: string, name: string) => {
    const productsInCat = (data.products || []).filter(p => p.categoryId === id);

    if (productsInCat.length > 0) {
      showToast(`لا يمكن حذف القسم "${name}" لأنه يحتوي على ${productsInCat.length} منتجات.`, 'error');
      return;
    }

    showConfirm(
      'حذف التصنيف',
      `هل أنت متأكد من حذف تصنيف "${name}"؟ لا يمكن التراجع عن هذا الإجراء.`,
      async () => {
        setIsLoading(true);
        try {
          await deleteCategory(id);
          showToast('تم حذف التصنيف بنجاح');
        } catch (error) {
          showToast('حدث خطأ أثناء الحذف', 'error');
          console.error('Error deleting category:', error);
        } finally {
          setIsLoading(false);
        }
      }
    );
  }, [data.products, deleteCategory, showConfirm, showToast]);

  // ============================================================
  // 🎨  العرض
  // ============================================================
  return (
    <div className="space-y-6">
      {/* 💬  الإشعارات */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      {/* ⚠️  نافذة التأكيد */}
      {confirmDialog && (
        <ConfirmDialog
          isOpen={confirmDialog.isOpen}
          title={confirmDialog.title}
          message={confirmDialog.message}
          onConfirm={() => {
            confirmDialog.onConfirm();
            setConfirmDialog(null);
          }}
          onCancel={() => setConfirmDialog(null)}
        />
      )}

      {/* 🏷️  رأس الصفحة */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-slate-900">إدارة تصنيفات المتجر</h1>
          <p className="text-xs text-slate-500 font-bold mt-0.5">ترتيب وتعديل وإضافة أقسام المنتجات</p>
        </div>

        <button
          type="button"
          onClick={handleOpenAdd}
          disabled={isLoading}
          className="flex items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-xs font-black text-white shadow hover:bg-orange-600 transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus size={16} aria-hidden="true" />
          <span>قسم جديد</span>
        </button>
      </div>

      {/* 📂  قائمة التصنيفات */}
      <div className="space-y-2.5">
        {categories.length === 0 ? (
          <div className="text-center py-16 text-slate-400">
            <p className="text-lg font-black">لا توجد تصنيفات</p>
            <p className="text-xs">أضف تصنيفاً جديداً باستخدام الزر أعلاه</p>
          </div>
        ) : (
          categories.map(cat => (
            <CategoryCard
              key={cat.id}
              category={cat}
              productsCount={getProductsCount(cat.id)}
              onEdit={handleOpenEdit}
              onDelete={handleDelete}
            />
          ))
        )}
      </div>

      {/* 📝  نافذة الإضافة/التعديل */}
      {isModalOpen && editingCategory && (
        <CategoryModal
          category={editingCategory}
          isOpen={isModalOpen}
          isLoading={isLoading}
          onClose={() => {
            setIsModalOpen(false);
            setEditingCategory(null);
          }}
          onSave={handleSave}
        />
      )}
    </div>
  );
};
