import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Trash2, 
  Printer, 
  Download, 
  CheckCircle2, 
  Truck, 
  Clock, 
  XCircle,
  Eye,
  Filter
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Order } from '../../types';

import { useSearchParams } from 'react-router-dom';

export const AdminOrdersPage: React.FC = () => {
  const { data, updateOrderStatus } = useShop();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialSearch = searchParams.get('id') || '';

  const [search, setSearch] = useState(initialSearch);
  const [statusFilter, setStatusFilter] = useState<'all' | Order['status']>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // تحديث البحث إذا تغير البارامتر في الرابط
  React.useEffect(() => {
    const id = searchParams.get('id');
    if (id) setSearch(id);
  }, [searchParams]);

  const orders = data.orders || [];
  const currencySymbol = data.settings.currencySymbol || 'ر.س';

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      const matchSearch =
        !search.trim() ||
        o.id.toLowerCase().includes(search.toLowerCase()) ||
        o.customer.name.toLowerCase().includes(search.toLowerCase()) ||
        o.customer.phone.includes(search);
      const matchStatus = statusFilter === 'all' || o.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [orders, search, statusFilter]);

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['رقم الطلب,اسم العميل,الهاتف,المدينة,العنوان,المبلغ,الحالة,التاريخ']
        .concat(
          orders.map(
            o =>
              `${o.id},"${o.customer.name}",${o.customer.phone},"${o.customer.city}","${o.customer.address}",${o.total},${o.status},${o.createdAt}`
          )
        )
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'orders-report.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">إدارة الطلبات</h1>
          <p className="text-xs text-slate-500 font-bold mt-0.5">
            متابعة حالة شحنات العملاء وتحديث مسار التوصيل
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 rounded-full bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-all shadow-sm"
        >
          <Download size={14} />
          <span>تصدير CSV</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-black/5">
        <div className="relative flex-1 min-w-[240px]">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="بحث برقم الطلب أو اسم العميل أو الجوال..."
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pe-4 ps-10 text-xs font-bold outline-none focus:border-orange-500 focus:bg-white"
          />
          <Search size={16} className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
        </div>

        {/* Status Filter Tabs */}
        <div className="flex flex-wrap gap-1">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'pending', label: 'قيد الانتظار' },
            { id: 'processing', label: 'قيد التجهيز' },
            { id: 'shipped', label: 'تم الشحن' },
            { id: 'delivered', label: 'تم التوصيل' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`rounded-xl px-3 py-1.5 text-xs font-black transition-all ${
                statusFilter === tab.id
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="overflow-x-auto rounded-3xl bg-white shadow-sm ring-1 ring-black/5">
        <table className="w-full text-start text-xs font-bold">
          <thead className="border-b border-slate-100 bg-slate-50 text-slate-400">
            <tr>
              <th className="p-3.5 text-start">رقم الطلب</th>
              <th className="p-3.5 text-start">العميل</th>
              <th className="p-3.5 text-start">المنتجات</th>
              <th className="p-3.5 text-start">الإجمالي</th>
              <th className="p-3.5 text-start">طريقة الدفع</th>
              <th className="p-3.5 text-start">الحالة</th>
              <th className="p-3.5 text-start">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredOrders.map(order => (
              <tr key={order.id} className="hover:bg-slate-50/60 transition-colors">
                <td className="p-3.5 font-black text-orange-600">#{order.id}</td>
                <td className="p-3.5">
                  <div className="text-slate-900">{order.customer.name}</div>
                  <div className="text-[10px] text-slate-400">{order.customer.city} · {order.customer.phone}</div>
                </td>
                <td className="p-3.5 max-w-[200px]">
                  <span className="line-clamp-1 text-slate-700">
                    {order.items.map(it => `${it.quantity}x ${it.name}`).join(' ، ')}
                  </span>
                </td>
                <td className="p-3.5 font-black text-slate-900">
                  {order.total} {currencySymbol}
                </td>
                <td className="p-3.5 text-slate-600">
                  {order.paymentMethod === 'cod'
                    ? 'عند الاستلام'
                    : order.paymentMethod === 'card'
                    ? 'بطاقة مدى/ائتمان'
                    : 'محفظة رقمية'}
                </td>
                <td className="p-3.5">
                  <select
                    value={order.status}
                    onChange={e => updateOrderStatus(order.id, e.target.value as any)}
                    className={`rounded-xl px-2.5 py-1 text-xs font-black outline-none border ${
                      order.status === 'delivered'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : order.status === 'shipped'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : order.status === 'cancelled'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}
                  >
                    <option value="pending">قيد الانتظار</option>
                    <option value="processing">قيد التجهيز</option>
                    <option value="shipped">تم الشحن</option>
                    <option value="delivered">تم التوصيل</option>
                    <option value="cancelled">ملغي</option>
                  </select>
                </td>
                <td className="p-3.5">
                  <button
                    onClick={() => setSelectedOrder(order)}
                    className="flex items-center gap-1 text-xs font-black text-slate-700 hover:text-orange-600"
                  >
                    <Eye size={14} />
                    <span>تفاصيل</span>
                  </button>
                </td>
              </tr>
            ))}

            {filteredOrders.length === 0 && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400">
                  لا توجد طلبات مطابقة
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-lg font-black text-slate-900">تفاصيل الطلب #{selectedOrder.id}</h2>
                <span className="text-xs text-slate-400 font-bold">
                  {new Date(selectedOrder.createdAt).toLocaleString('ar-SA')}
                </span>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="rounded-full bg-slate-100 p-1 text-slate-500 hover:bg-slate-200"
              >
                <XCircle size={20} />
              </button>
            </div>

            {/* Customer Information */}
            <div className="rounded-2xl bg-slate-50 p-4 space-y-1.5 text-xs font-bold">
              <span className="text-slate-400 block mb-1">معلومات العميل</span>
              <div className="text-slate-900 font-black">{selectedOrder.customer.name}</div>
              <div className="text-slate-600">{selectedOrder.customer.city} · {selectedOrder.customer.address}</div>
              <div className="text-slate-600" dir="ltr">{selectedOrder.customer.phone}</div>
            </div>

            {/* Products List */}
            <div className="space-y-2">
              <span className="text-xs font-black text-slate-900 block">المنتجات المطلوبة</span>
              {selectedOrder.items.map((it, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl border border-slate-100 p-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <img src={it.image} className="h-10 w-10 rounded-lg object-cover" alt="" />
                    <div>
                      <div className="font-bold text-slate-900">{it.name}</div>
                      <div className="text-[10px] text-slate-400">الكمية: {it.quantity}</div>
                    </div>
                  </div>
                  <span className="font-black text-slate-900">
                    {it.price * it.quantity} {currencySymbol}
                  </span>
                </div>
              ))}
            </div>

            {/* Total breakdown */}
            <div className="border-t border-slate-100 pt-3 space-y-1.5 text-xs font-bold">
              <div className="flex justify-between text-slate-500">
                <span>المجموع الفرعي:</span>
                <span>{selectedOrder.subtotal} {currencySymbol}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>رسوم التوصيل:</span>
                <span>{selectedOrder.shipping === 0 ? 'مجاني' : `${selectedOrder.shipping} ${currencySymbol}`}</span>
              </div>
              <div className="flex justify-between text-base font-black text-slate-900 border-t border-slate-100 pt-2">
                <span>الإجمالي:</span>
                <span className="text-orange-600">{selectedOrder.total} {currencySymbol}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                <Printer size={14} />
                <span>طباعة الفاتورة</span>
              </button>
              <button
                onClick={() => setSelectedOrder(null)}
                className="rounded-xl bg-slate-900 px-5 py-2 text-xs font-bold text-white hover:bg-slate-800"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
