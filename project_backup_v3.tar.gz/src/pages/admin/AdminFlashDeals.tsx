import React, { useState, useMemo } from 'react';
import { Zap, Clock, Search } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminFlashDealsPage: React.FC = () => {
  const { data, updateProduct } = useShop();
  const [search, setSearch] = useState('');

  const products = data.products || [];
  const currencySymbol = data.settings.currencySymbol || 'ر.س';

  const filtered = useMemo(() => {
    return products.filter(
      p => !search.trim() || p.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [products, search]);

  const handleToggleFlash = (id: string, current: boolean) => {
    const next = !current;
    updateProduct(id, {
      flashDeal: next,
      flashEndsAt: next ? new Date(Date.now() + 8 * 3600 * 1000).toISOString() : undefined
    });
  };

  const handleExtend = (id: string, hours: number) => {
    updateProduct(id, {
      flashDeal: true,
      flashEndsAt: new Date(Date.now() + hours * 3600 * 1000).toISOString()
    });
    alert(`تم تمديد العرض لمدة ${hours} ساعة`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
          <span>عروض البرق</span>
          <Zap className="text-orange-500" size={24} />
        </h1>
        <p className="text-xs text-slate-500 font-bold mt-0.5">
          تفعيل وتمديد عروض البرق المؤقتة على المنتجات
        </p>
      </div>

      <div className="relative max-w-sm">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="بحث في المنتجات..."
          className="w-full rounded-2xl border border-slate-200 bg-white py-2.5 pe-4 ps-10 text-xs font-bold outline-none focus:border-orange-500 shadow-sm"
        />
        <Search size={16} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(prod => (
          <div
            key={prod.id}
            className={`rounded-3xl p-4 shadow-sm ring-1 transition-all ${
              prod.flashDeal
                ? 'bg-gradient-to-br from-red-50 to-orange-50 ring-orange-300'
                : 'bg-white ring-black/5'
            }`}
          >
            <div className="flex gap-3 mb-3">
              <img src={prod.images[0]} className="h-16 w-16 rounded-2xl object-cover bg-white" alt="" />
              <div className="flex-1">
                <h3 className="font-black text-xs text-slate-900 line-clamp-1">{prod.name}</h3>
                <div className="text-xs font-black text-orange-600 mt-1">
                  {prod.price} {currencySymbol}{' '}
                  <span className="text-[10px] text-slate-400 line-through">
                    {prod.originalPrice} {currencySymbol}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-bold mt-0.5">
                  المخزون: {prod.stock} قطعة
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-slate-200/60 pt-3">
              <button
                onClick={() => handleToggleFlash(prod.id, Boolean(prod.flashDeal))}
                className={`rounded-full px-3 py-1.5 text-xs font-black transition-all ${
                  prod.flashDeal
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {prod.flashDeal ? '⚡ عرض نشط' : 'تفعيل العرض'}
              </button>

              {prod.flashDeal && (
                <div className="flex items-center gap-1 text-[11px] font-bold">
                  <span className="text-slate-500">تمديد:</span>
                  <button
                    onClick={() => handleExtend(prod.id, 4)}
                    className="rounded-lg bg-white px-2 py-1 shadow-sm border border-slate-200 hover:bg-orange-50 hover:text-orange-600"
                  >
                    +4h
                  </button>
                  <button
                    onClick={() => handleExtend(prod.id, 8)}
                    className="rounded-lg bg-white px-2 py-1 shadow-sm border border-slate-200 hover:bg-orange-50 hover:text-orange-600"
                  >
                    +8h
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
